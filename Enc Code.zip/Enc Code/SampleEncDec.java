package com.icici;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class SampleEncDec {
	
	static final String SYMM_CIPHER = "AES/CBC/PKCS5PADDING";
	static final String ASYMM_CIPHER = "RSA/ECB/PKCS1Padding";
	
//	static final String KEYSTORE_FILE = "D:\\RV\\MyWork\\eclipse-jee-oxygen-3a-win32\\workspace\\z-apigw-crypt\\resources\\sample-dummy.p12";//Uncomment this
	static final String KEYSTORE_FILE = "D:\\\\Jagdeep\\\\Work\\\\Sample-EncDec-SymmAsymm\\\\sample-dummy.p12";
	static final String KEYSTORE_PWD = "Password";
	static final String KEYSTORE_ALIAS = "sample-dummy";
	static final String KEYSTORE_INSTANCE = "PKCS12";
	
//	static final String PUBLIC_KEY = "D:\\RV\\MyWork\\eclipse-jee-oxygen-3a-win32\\workspace\\z-apigw-crypt\\resources\\sample-dummy.pem";//Uncomment this
	static final String PUBLIC_KEY = "D:\\Jagdeep\\Work\\Sample-EncDec-SymmAsymm\\sample-dummy.pem";
	
	public static void main(String[] args) throws GeneralSecurityException, IOException {
		
		// Random Number
		final String sessionKey = "qqqqwwww11112222";
		
		final String payload = "{\"msg\" : \"Hello !!\"}";
		
		// Random 16 bytes of IV
		final String iv = "aaaabbbbccccdddd";
		
		// Symmetrically
//		final String encryptedData = encryptSymm(sessionKey, iv, payload);
//		System.out.println(String.format("EncryptedPayload :: %s", encryptedData));
//		
//		String decryptedPayload = decryptSymm(sessionKey, encryptedData);
//		System.out.println(String.format("DecryptedPayload :: %s", decryptedPayload));
		
		//Asymmetrically
		
		String encryptedKey = encryptAsymm(Base64.getEncoder().encodeToString(payload.getBytes()), PUBLIC_KEY);
		System.out.println(String.format("EncryptedKey :: %s", encryptedKey));
		String plainKey = decryptAsymm(encryptedKey, KEYSTORE_FILE);
		System.out.println(String.format("DecryptedSessionKey :: %s", plainKey));
		
	}

	// Method to Encrypt Payload Symmetrically
	public static String encryptSymm(String key, String initVector, String value) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance(SYMM_CIPHER);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
			byte[] encrypted = cipher.doFinal(value.getBytes());
//			System.out.println("encrypted string: " + new String(Utility.b64Encode(encrypted)));

			byte[] c = new byte[initVector.getBytes("UTF-8").length + encrypted.length];
			System.arraycopy(initVector.getBytes("UTF-8"), 0, c, 0, initVector.getBytes("UTF-8").length);
			System.arraycopy(encrypted, 0, c, initVector.getBytes("UTF-8").length, encrypted.length);
			return Base64.getEncoder().encodeToString(c);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}
	
	// Method to Decrypt Payload Symmetrically
	public static String decryptSymm(final String key,final String encryptedStr) {
		try {
			byte[] encrypted = Base64.getDecoder().decode(encryptedStr.getBytes());
			byte[] iv = Arrays.copyOfRange(encrypted, 0, 16);
			byte[] ciphertext = Arrays.copyOfRange(encrypted, iv.length, encrypted.length);

			IvParameterSpec ivPS = new IvParameterSpec(iv);
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance(SYMM_CIPHER);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivPS);

			byte[] original = cipher.doFinal(ciphertext);
			return new String(original);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public static String encryptAsymm(String b64Msg, String filePath)
			throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, CertificateException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(ASYMM_CIPHER);
		Key key = loadPublicKeyFromFile(filePath);
		byte[] msg = Base64.getDecoder().decode(b64Msg);
//		System.out.println("MSG :: " + new String(msg));
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] encryptedMsg = cipher.doFinal(msg);
		return Base64.getEncoder().encodeToString(encryptedMsg);
	}

	public static String decryptAsymm(String b64EncryptedMsg, String filePath)
			throws NoSuchAlgorithmException, NoSuchPaddingException, CertificateException, InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException, UnrecoverableKeyException, KeyStoreException, IOException {
		Cipher cipher = Cipher.getInstance(ASYMM_CIPHER);
		Key key = loadPrivateKeyFromFile(filePath);
		byte[] encryptedMsg = Base64.getDecoder().decode(b64EncryptedMsg);
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] decryptedMsg = cipher.doFinal(encryptedMsg);
		return new String(decryptedMsg);
	}
	
	private static Key loadPublicKeyFromFile(String publicKeyPath) throws CertificateException, FileNotFoundException {
		Key key = null;
		X509Certificate x509Certificate = createCert(publicKeyPath);
		key = x509Certificate.getPublicKey();
		return key;
	}

	private static X509Certificate createCert(String filePath) {
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X509");
			X509Certificate cert = (X509Certificate) cf.generateCertificate(new FileInputStream(filePath));
			return cert;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private static Key loadPrivateKeyFromFile(String privateKeyPath) throws CertificateException, KeyStoreException,
		NoSuchAlgorithmException, IOException, UnrecoverableKeyException {
	Key key = null;
	KeyStore keyStore = KeyStore.getInstance(KEYSTORE_INSTANCE);
	keyStore.load(new FileInputStream(KEYSTORE_FILE), KEYSTORE_PWD.toCharArray());
	key = keyStore.getKey(KEYSTORE_ALIAS, KEYSTORE_PWD.toCharArray());
	return key;
	}
}
